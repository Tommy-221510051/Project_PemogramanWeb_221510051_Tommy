<footer class="footer_part">
    <div class="container">
        <div class="row justify-content-around">
            <div class="col-sm-6 col-lg-2">
                <div class="single_footer_part">
                    <h4>Kategori Produk</h4>
                    <ul class="list-unstyled">
                        <li><a href="">Tanaman Hias</a></li>
                        <li><a href="">Tanaman udara</a></li>
                        <li><a href="">Tanaman kelembapan</a></li>
                        <li><a href="">Tanaman dedaun</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-6 col-lg-2">
                <div class="single_footer_part">
                    <h4>Layanan Pelanggan</h4>
                    <ul class="list-unstyled">
                        <li><a href="">Bantuan</a></li>
                        <li><a href="">Lacak Pesanan</a></li>
                        <li><a href="">Pesanan Saya</a></li>
                        <li><a href="">Gratis Ongkir</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-6 col-lg-2">
                <div class="single_footer_part">
                    <h4>Jelajahi</h4>
                    <ul class="list-unstyled">
                        <li><a href="">Contact</a></li>
                        <li><a href="">Tentang kami</a></li>
                        <li><a href="">Blog</a></li>
                        <li><a href="">Flash sale</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-6 col-lg-2">
                <div class="single_footer_part">
                    <h4>Resource</h4>
                    <ul class="list-unstyled">
                        <li><a href="">Panduan</a></li>
                        <li><a href="">Research</a></li>
                        <li><a href="">Experts</a></li>
                        <li><a href="">Agen</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-6 col-lg-4">
                <div class="single_footer_part">
                    <h4>Join member kami </h4>
                    <p>
                        Berlangganan agar mendapatkan informasi terbaru tentang penawaran baru
                    </p>
                    <div id="mc_embed_signup">
                        <form target="_blank" action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01" method="get" class="subscribe_form relative mail_part">
                            <input type="email" name="email" id="newsletter-form-email" placeholder="alamat Email" class="placeholder hide-on-focus" onfocus="this.placeholder = ''" onblur="this.placeholder = ' Email Address '" />
                            <button type="submit" name="submit" id="newsletter-submit" class="email_icon newsletter-submit button-contactForm">
                                Kirim
                            </button>
                            <div class="mt-10 info"></div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright_part">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="copyright_text">
                        <p>
                            Celestial Flora &copy;
                            <script>
                                document.write(new Date().getFullYear());
                            </script>
                            Hak cipta
                            <a href="" target="_blank">tidak dilindungi</a>
                        </p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="footer_icon social_icon">
                        <ul class="list-unstyled">
                            <li>
                                <a href="#" class="single_social_icon"><i class="fab fa-facebook-f"></i></a>
                            </li>
                            <li>
                                <a href="#" class="single_social_icon"><i class="fab fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href="#" class="single_social_icon"><i class="fas fa-globe"></i></a>
                            </li>
                            <li>
                                <a href="#" class="single_social_icon"><i class="fab fa-behance"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>


