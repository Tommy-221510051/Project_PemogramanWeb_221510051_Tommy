
    <div class="sidebar">
        <a class="active" href="/ecommerce/admin">Home</a>
        <a href="product.php">Add Product</a>
        <a href="products.php">All Products</a>
        <a href="order.php">Customer Orders</a>
        <a href="users.php">All Customers</a>
    </div>